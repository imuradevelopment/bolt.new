export const CONTINUE_PROMPT = 'Continue where you left off. Continue your last response.';


